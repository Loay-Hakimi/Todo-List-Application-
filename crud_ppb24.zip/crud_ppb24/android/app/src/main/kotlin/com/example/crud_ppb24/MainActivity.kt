package com.example.crud_ppb24

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
