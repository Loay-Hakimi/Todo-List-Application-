# https://firebase.google.com/support/release-notes/ios
def firebase_sdk_version!()
  '11.4.0'
end
