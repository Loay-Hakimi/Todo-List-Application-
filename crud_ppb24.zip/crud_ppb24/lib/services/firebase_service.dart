import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final CollectionReference _tasksCollection =
      _firestore.collection('tasks');

  static Future<void> addTask(String title, String description) async {
    try {
      await _tasksCollection.add({
        'title': title,
        'description': description,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      throw Exception('Error adding task: $e');
    }
  }

  static Stream<QuerySnapshot> getTasks() {
    return _tasksCollection.orderBy('createdAt', descending: true).snapshots();
  }

  static Future<void> updateTask(
      String taskId, String title, String description) async {
    try {
      await _tasksCollection.doc(taskId).update({
        'title': title,
        'description': description,
      });
    } catch (e) {
      throw Exception('Error updating task: $e');
    }
  }

  static Future<void> deleteTask(String taskId) async {
    try {
      await _tasksCollection.doc(taskId).delete();
    } catch (e) {
      throw Exception('Error deleting task: $e');
    }
  }
}
